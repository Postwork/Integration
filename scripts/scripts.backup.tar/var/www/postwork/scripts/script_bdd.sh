#!/bin/bash
requete=$(mysql -u adduser -pHfeufier -e "SELECT user FROM mysql.user WHERE user='$2';") #recupere le nom de l'utilisateur
nom=`echo $requete | awk '{ print $2}'` 
case $1 in
	1)
		if [[ -z $nom ]];
		then
        		mysql -u root -pp05Twork2015sBFJ -e "
        		CREATE USER "$2"@"localhost" IDENTIFIED BY '$3'; 
			CREATE DATABASE $2;   
			GRANT CREATE,DROP,SELECT,INSERT,DELETE,UPDATE ON $2.* TO "$2"@"localhost" ;	 #donne les droits necessaire
			FLUSH PRIVILEGES ;" 	#permet de rafraichir les tables de droits pour prendre en compte les modifications
        		echo create
		else
			exit 1
		fi
	;;
	
	2)

		if [[ -n $nom ]];
		then
			mysql -u adduser -pHfeufier -e "
        		DROP USER "$2"@"localhost" ;
			DROP DATABASE $2 ;
			FLUSH PRIVILEGES ;"
			echo delete
		else 
			exit 1
		fi
	;;
esac
