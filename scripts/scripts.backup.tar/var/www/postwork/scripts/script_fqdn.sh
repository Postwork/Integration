#!/bin/bash
cd /etc/tinydns/root/
test=`cat data | grep $2`
case $1 in
	1 )
		if [[ -z $test ]]; then
			if [[ -n $3 ]]; then
				echo "=$2:$3" >> data
			else
				echo "=$2:88.177.168.133" >> data
			fi
		qrencode "$2" -o /var/www/$2/$2.png
		chown $2:$2 /var/www/$2/$2.png

		else
			exit 1
		fi	
	;;
	2 )
		if [[ -n $test ]]; then
			sed -i -e "/$2/d" data
		else
			exit 1
		fi
	;;
esac
make
ssh -i /home/freddy/.ssh/id_rsa root@dedibox.itinet.fr
