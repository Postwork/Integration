#!/bin/bash
cd /etc/postfix/
test=`cat vmailbox | grep $2`
case $1 in
	1 )
		if [[ -z $test ]]; then
			echo "$2@postwork.itinet.fr postwork.itinet.fr/$2/" >> vmailbox
		else
			exit 1
		fi	
	;;
	2 )
		if [[ -n $test ]]; then
			sed -i -e "/$2/d" vmailbox
			rm -R /var/mail/$2
		else
			exit 1
		fi	
	;;
esac
postmap vmailbox
postfix reload
