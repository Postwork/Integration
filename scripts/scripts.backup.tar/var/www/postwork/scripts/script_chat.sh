#!/bin/bash
case $1 in
 	1 ) sudo prosodyctl adduser $2@postwork.itinet.fr ;;
	2 ) sudo prosodyctl deluser $2@postwork.itinet.fr ;;
esac 

