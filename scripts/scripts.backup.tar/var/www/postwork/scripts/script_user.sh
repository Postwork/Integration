#!/bin/bash
case $1 in
	1 )
		if [[ -n $3 ]]; then
			useradd -m -d /var/mail/$2 -s /usr/bin/mysecureshell -p $(openssl passwd -1 $3) $2
			edquota -p freddy $2
			mkdir /var/www/$2
			chown $2:$2 /var/www/$2
		else
			exit 1
		fi
	;;
	2 )
		userdel -f $2
		rm -R /var/www/$2
	;;
esac
