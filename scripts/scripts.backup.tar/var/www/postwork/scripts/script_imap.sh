#!/bin/bash
cd /etc/courier/  #se placer dans le répertoire de courier-imap
test=`cat userdb | grep $2`  #cherche le nom dans le fichier userdb
case $1 in
	1)
		if [[ -z $test ]];	#teste si le nom n'existe pas
		then
			userdb $2 set imappw=$(openssl passwd -1 $3) uid=5000 gid=5000 home=/var/mail/$2 mail=/var/mail/$2 	#ajoute l'utiliser au fichier userdb
		mail -s "Bienvenue" $2@postwork.itinet.fr <<< 'Merci de nous avoir rejoint sur  Postwork. Cordialement, PwTeam'
		else
			exit 1
		fi
	;;
	2)
		if [[ -n $test ]];
		then
			sed -i -e "/$2/d" userdb	#supprime l'utilisateur du fichier
		else
			exit 1
		fi
	;;
esac
makeuserdb	#crée/met à jour le fichier exploitable 
