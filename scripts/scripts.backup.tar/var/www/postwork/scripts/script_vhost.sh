#!/bin/bash
case $1 in
	1 )
		cp /etc/nginx/sites-available/vhost_defaut /etc/nginx/sites-available/$2
		sed -i -e "s&defautrepo&$3&g" /etc/nginx/sites-available/$2
		sed -i -e "s&defautfqdn&$2&g" /etc/nginx/sites-available/$2
		ln -s /etc/nginx/sites-available/$2 /etc/nginx/sites-enabled/
	;;
	2 )
		if [[ -f /etc/nginx/sites-available/$2 ]]; then
			rm /etc/nginx/sites-available/$2 | rm /etc/nginx/sites-enabled/$2
		else
			exit 1
		fi
	;;
esac
nginx -s reload
